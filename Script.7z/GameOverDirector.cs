using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameOverDirector : MonoBehaviour
{
    GameObject YourScore;
    void Start()
    {
        YourScore = GameObject.Find("YourScore");
        float score = PlayerPrefs.GetFloat("Score",0f);
        if (score >= 0&&score<10000)
        {
            this.YourScore.GetComponent<Text>().text = "Your Score:" + score+"\n"+"Try Again!";
        }
        else if(score<=20000&&score>=10000)
        {
            this.YourScore.GetComponent<Text>().text = "Your Score:" + score+"\n"+"Nice Try!";
        }
        else
        {
            this.YourScore.GetComponent<Text>().text = "Your Score:" + score+"\n" + "Very Good Grade";
        }

    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            SceneManager.LoadScene("GameStart");
        }
    }
}
