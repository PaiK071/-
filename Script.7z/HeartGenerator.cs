using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeartGenerator : MonoBehaviour
{
    public GameObject HeartPrefab;

    float cooltime=10.0f;
    float delta = 0;
    void Start()
    {
        
    }

    void Update()
    {
        this.delta += Time.deltaTime;
        if(this.delta>this.cooltime)
        {
            this.delta = 0;
            GameObject go = Instantiate(HeartPrefab);
            int px = Random.Range(-7, 7);//��Ʈ�� ���� x�� ��ǥ
            int py = Random.Range(-2, 0);//��Ʈ�� ���� y�� ��ǥ
            go.transform.position = new Vector3(px, py, 0);
        }
    }
}
