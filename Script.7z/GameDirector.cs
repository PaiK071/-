using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameDirector : MonoBehaviour
{
    GameObject hpGauge;
    GameObject player;
    GameObject Score;
    GameObject Boost;
    GameObject BoostCool;

    public float playerHp = 100.0f;
    float score = 1;
    void Start()
    {
        this.hpGauge = GameObject.Find("hpGauge");
        this.Score = GameObject.Find("Score");
        this.Boost = GameObject.Find("Boost");
        this.BoostCool = GameObject.Find("BoostCool");
        this.BoostCool.SetActive(true);
        this.Boost.SetActive(false);
    }
    private void Update()
    {
        if (score < 1000)
            score += 1;
        else if (score >= 1000 && score < 10000)
            score += 2;
        else if (score >= 10000 && score < 50000)
            score += 3;
        else
            score += 5;
        this.Score.GetComponent<Text>().text = "Score:" + score;
        PlayerPrefs.SetFloat("Score", score);
        if (playerHp<=1)
        {
            SceneManager.LoadScene("GameOver");
        }

    }

    public void DecreaseHp()
    {
        if (score < 10000)
        {
            this.hpGauge.GetComponent<Image>().fillAmount -= 0.1f;
            playerHp -= 10f;
        }
        else if (score >= 10000)
        {
            this.hpGauge.GetComponent<Image>().fillAmount -= 0.2f;
            playerHp -= 20f;
        }

    }
    public void IncreaseHp()
    {
        if (playerHp < 105)
        {
            if (playerHp > 80)//ü���� 80�̻��϶��� 10�� ȸ���ؼ� 100�� �Ѿ�� �ʰ� ��
            {
                playerHp += 10f;
                this.hpGauge.GetComponent<Image>().fillAmount += 0.1f;
            }
            else
            {
                this.hpGauge.GetComponent<Image>().fillAmount += 0.2f;
                playerHp += 20;
            }
        }
    }
    public void BoostOn()
    {
        this.BoostCool.SetActive(false);
        this.Boost.SetActive(true);

    }
    public void BoostOff()
    {
        this.Boost.SetActive(false);

    }
    public void IsBoostOn()
    {
        this.BoostCool.SetActive(true);
    }
    public void IsBoostOff()
    {
        this.BoostCool.SetActive(false);
    }
}
